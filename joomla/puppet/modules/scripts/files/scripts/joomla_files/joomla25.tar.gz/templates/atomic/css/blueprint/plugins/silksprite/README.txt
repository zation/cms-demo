README 

http://www.ajaxbestiary.com/Labs/SilkSprite/
